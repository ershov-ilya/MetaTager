<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Для использования в проектах построенных на MODX Revolution',
    'readme' => 'Устанавливает в систему сниппеты:
1) MetaTager
Этот сниппет выводит все необходимые мета-теги: title, description, keywords, base, link[canonical] and favicon. Он пытается заполнить все необходимые поля автоматически, на основе имеющихся данных.

2) CopyDate
Сниппет для вывода текущего года и знака копирайта

3) GET
Сниппет для получения значения поля $_GET, $_POST или $_REQUEST

4) parent
Сниппет для получения ID родителя или любого другого поля у текущего ресурса, если указать параметр &id - можно получить поля родителя любого другого ресурса

5) title
Сниппет который выводит longtitle, а если там пусто - выведет pagetitle',
    'changelog' => '/* MetaTager ver.1.3.0
---------------------------------------------------------*/
- Рефакторинг сниппета MetaTager
- Добавлены сниппеты: CopyDate, GET, parent, title

/* MetaTager ver.1.2.0-beta
---------------------------------------------------------*/
- Добавлена совместимость со Sterc SEOPro
- Добавлен вывод мета тега Charset

/* MetaTager ver.1.1.1-beta
---------------------------------------------------------*/
- Добавлен чанк title
- В пакет добавлена библиотека Grayscale под JQuery

/* MetaTager ver.1.1.0-beta
---------------------------------------------------------*/
- Добавлены чанки preHead и postHead
- В пакет добавлены библиотеки JQuery и её плагины (Colorbox, Vegas, timers и т.д.) путь записи /assets/components/metatager/lib/

/* MetaTager ver.1.0.0-beta
---------------------------------------------------------*/
- Создан чанк metatager
- Первый выпуск',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '567238099184f717e436e59cf5dd2499',
      'native_key' => 'metatager',
      'filename' => 'modNamespace/6764ab1469c1bbb1ac4404ec24c4ea6d.vehicle',
      'namespace' => 'metatager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'bedcb84895342564ab4db3728a826fe1',
      'native_key' => 1,
      'filename' => 'modCategory/da9d5ede2bcd2087bbe447c307145de3.vehicle',
      'namespace' => 'metatager',
    ),
  ),
);